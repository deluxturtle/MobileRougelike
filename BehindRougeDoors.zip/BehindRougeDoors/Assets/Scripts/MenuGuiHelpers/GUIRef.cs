﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GUIRef : MonoBehaviour {

    public Text Score;
}
