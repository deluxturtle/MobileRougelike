﻿using UnityEngine;

public class ScriptNodeRecord {

    public GameObject node;
    public ScriptNodeRecord connection;
    public int costSoFar;
}
