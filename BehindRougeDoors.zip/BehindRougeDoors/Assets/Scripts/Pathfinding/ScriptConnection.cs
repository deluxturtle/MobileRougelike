﻿using UnityEngine;
using System.Collections;

public class ScriptConnection {

    public GameObject from;
    public GameObject goingTo;
    public int cost;
}
